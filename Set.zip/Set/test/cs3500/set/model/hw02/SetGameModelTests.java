package cs3500.set.model.hw02;

import cs3500.set.model.hw02.*;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Tests for the SetGameModel Interface
 */
public class SetGameModelTests {
  private SetThreeGameModel model1;
  private SetThreeGameModel model2;
  private Cards card1;
  private Cards card2;
  private Cards card3;
  private List<Cards> deck;
  private List<Cards> deck2;


  @Before
  public void initialConditions() {
    model1 = new SetThreeGameModel();

    model2 = new SetThreeGameModel();
    deck = model2.getCompleteDeck();
    model2.startGameWithDeck(deck, 3, 3);

//    card1 = new Cards(1, Fill.FULL, Shape.OVAL);
//    card2 = new Cards(2, Fill.STRIPED, Shape.DIAMOND);
//    card3 = new Cards(3, Fill.EMPTY, Shape.SQUIGGLE);
//    deck2 = new ArrayList<Cards>(Arrays.asList(card1, card2, card3,
//        card1, card2, card3, card1, card2, card3));
  }

  @Test
  public void testIsGameOver() {
    assertTrue(model1.isGameOver());

    model2.startGameWithDeck(deck, 3, 3);
    assertFalse(model2.isGameOver());
  }

  @Test
  public void testGetWidth() {
    try {
      assertEquals(model1.getWidth(), 3);
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertEquals(model2.getWidth(), 3);
  }

  @Test
  public void testGetHeight() {
    try {
      assertEquals(model1.getHeight(), 3);
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertEquals(model2.getHeight(), 3);
  }

  @Test
  public void testGetScore() {
    try {
      assertEquals(model1.getScore(), 0);
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertEquals(model2.getScore(), 0);
  }

  @Test
  public void testGetCardAtCoord() {
    try {
      assertEquals(model1.getCardAtCoord(0, 0), new Cards(1, Fill.FULL, Shape.OVAL));
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertEquals(model2.getCardAtCoord(0, 0), new Cards(1, Fill.FULL, Shape.OVAL));
    Coord coord1 = new Coord(0, 1);
    assertEquals(model2.getCardAtCoord(coord1), new Cards(2, Fill.FULL, Shape.OVAL));
  }

  @Test
  public void testIsValidSet() {
    try {
      assertTrue(model1.isValidSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2)));
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertTrue(model2.isValidSet(new Coord(0, 0), new Coord(0, 1), new Coord(0, 2)));
    assertFalse(model2.isValidSet(new Coord(0, 0), new Coord(0, 1), new Coord(1, 2)));
  }

  @Test
  public void testAnySetsPresent() {
    try {
      assertTrue(model1.anySetsPresent());
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    assertTrue(model2.anySetsPresent());

    Cards card1 = new Cards(1, Fill.FULL, Shape.SQUIGGLE);
    Cards card2 = new Cards(2, Fill.FULL, Shape.SQUIGGLE);
    Cards card3 = new Cards(1, Fill.STRIPED, Shape.OVAL);
    Cards card4 = new Cards(3, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card5 = new Cards(3, Fill.FULL, Shape.DIAMOND);
    Cards card6 = new Cards(1, Fill.STRIPED, Shape.OVAL);
    Cards card7 = new Cards(1, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card8 = new Cards(2, Fill.STRIPED, Shape.DIAMOND);
    Cards card9 = new Cards(1, Fill.EMPTY, Shape.OVAL);
    List<Cards> newDeck = new ArrayList<>(Arrays.asList(card1, card2, card3, card4, card5, card6, card7, card8, card9));
    model1.startGameWithDeck(newDeck, 3, 3);
    assertFalse(model1.anySetsPresent());
  }

  @Test
  public void testGetCompleteDeck() {
    Cards card1 = new Cards(1, Fill.FULL, Shape.OVAL);
    Cards card2 = new Cards(2, Fill.FULL, Shape.OVAL);
    Cards card3 = new Cards(3, Fill.FULL, Shape.OVAL);
    Cards card4 = new Cards(1, Fill.FULL, Shape.SQUIGGLE);
    Cards card5 = new Cards(2, Fill.FULL, Shape.SQUIGGLE);
    Cards card6 = new Cards(3, Fill.FULL, Shape.SQUIGGLE);
    Cards card7 = new Cards(1, Fill.FULL, Shape.DIAMOND);
    Cards card8 = new Cards(2, Fill.FULL, Shape.DIAMOND);
    Cards card9 = new Cards(3, Fill.FULL, Shape.DIAMOND);
    Cards card10 = new Cards(1, Fill.EMPTY, Shape.OVAL);
    Cards card11 = new Cards(2, Fill.EMPTY, Shape.OVAL);
    Cards card12 = new Cards(3, Fill.EMPTY, Shape.OVAL);
    Cards card13 = new Cards(1, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card14 = new Cards(2, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card15 = new Cards(3, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card16 = new Cards(1, Fill.EMPTY, Shape.DIAMOND);
    Cards card17 = new Cards(2, Fill.EMPTY, Shape.DIAMOND);
    Cards card18 = new Cards(3, Fill.EMPTY, Shape.DIAMOND);
    Cards card19 = new Cards(1, Fill.STRIPED, Shape.OVAL);
    Cards card20 = new Cards(2, Fill.STRIPED, Shape.OVAL);
    Cards card21 = new Cards(3, Fill.STRIPED, Shape.OVAL);
    Cards card22 = new Cards(1, Fill.STRIPED, Shape.SQUIGGLE);
    Cards card23 = new Cards(2, Fill.STRIPED, Shape.SQUIGGLE);
    Cards card24 = new Cards(3, Fill.STRIPED, Shape.SQUIGGLE);
    Cards card25 = new Cards(1, Fill.STRIPED, Shape.DIAMOND);
    Cards card26 = new Cards(2, Fill.STRIPED, Shape.DIAMOND);
    Cards card27 = new Cards(3, Fill.STRIPED, Shape.DIAMOND);
    List<Cards> newDeck = new ArrayList<>(Arrays.asList(card1, card2, card3, card4, card5, card6, card7, card8, card9,
        card10, card11, card12, card13, card14, card15, card16, card17, card18, card19, card20, card21, card22, card23,
        card24, card25, card26, card27));

    assertEquals(model2.getCompleteDeck(), newDeck);
  }

  @Test
  public void testClaimSet() {
    Coord coord1 = new Coord(0, 0);
    Coord coord2 = new Coord(0, 1);
    Coord coord3 = new Coord(0, 2);
    Coord coord4 = new Coord(2, 2);
    Coord coord5 = new Coord(1, 1);

    try {
      model1.claimSet(coord1, coord2, coord4);
      fail("IllegalStateException not thrown");
    } catch (IllegalStateException e) {
      // do nothing
    }
    try {
      model2.claimSet(coord1, coord2, coord4);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }

    assertEquals(model2.getScore(), 0);
    model2.claimSet(coord1, coord2, coord3);
    assertEquals(model2.getScore(), 1);

    initialConditions();

    assertEquals(model2.getScore(), 0);
    model2.claimSet(coord1, coord4, coord5);
    assertEquals(model2.getScore(), 1);
  }

  @Test
  public void testStartGameWithDeck() {
    try {
      model1.startGameWithDeck(null, 3, 4);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    try {
      model1.startGameWithDeck(new ArrayList<Cards>(), 3, 3);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    try {
      model1.startGameWithDeck(null, 2, 3);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    assertTrue(model1.isGameOver());
    model1.startGameWithDeck(deck, 3, 3);
    assertFalse(model1.isGameOver());
  }

}
