package cs3500.set.model.hw02;

import cs3500.set.model.hw02.Cards;
import cs3500.set.model.hw02.SetGameModelState;
import cs3500.set.model.hw02.SetThreeGameModel;
import cs3500.set.view.SetGameTextView;
import cs3500.set.view.SetGameView;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class ViewTests {
  private SetGameModelState model1;
  private List<Cards> deck;

  @Before
  public void InitialConditions() {
    model1 = new SetThreeGameModel();
    deck = model1.getCompleteDeck();
  }

  @Test
  public void testInitialization() {
    try {
      SetGameView view = new SetGameTextView(null);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    SetGameView view = new SetGameTextView(model1);
  }

  @Test
  public void testToString() {
    SetGameView view = new SetGameTextView(model1);
    assertEquals(view.toString(), "1FO 2FO 3FO\n" +
        "1FQ 2FQ 3FQ\n" +
        "1FD 2FD 3FD");
  }

}
