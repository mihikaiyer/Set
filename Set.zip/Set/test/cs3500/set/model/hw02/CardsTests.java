package cs3500.set.model.hw02;

import cs3500.set.model.hw02.Cards;
import cs3500.set.model.hw02.Fill;
import cs3500.set.model.hw02.Shape;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class CardsTests {

  @Test
  public void TestInitialization() {
    try {
      Cards badCard = new Cards(0, Fill.EMPTY, Shape.OVAL);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    try {
      Cards badCard = new Cards(1, null, Shape.SQUIGGLE);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    try {
      Cards badCard = new Cards(1, Fill.EMPTY, null);
      fail("IllegalArgumentException not thrown");
    } catch (IllegalArgumentException e) {
      // do nothing
    }

    Cards card1 = new Cards(1, Fill.EMPTY, Shape.SQUIGGLE);
    assertEquals(card1.getNumber(), 1);
    assertEquals(card1.getFill(), Fill.EMPTY);
    assertEquals(card1.getShape(), Shape.SQUIGGLE);
  }

  @Test
  public void testToString() {
    Cards card1 = new Cards(1, Fill.EMPTY, Shape.SQUIGGLE);
    Cards card2 = new Cards(2, Fill.FULL, Shape.SQUIGGLE);

    assertEquals(card1.toString(), "1EQ");
    assertEquals(card2.toString(), "2FQ");
  }
}
