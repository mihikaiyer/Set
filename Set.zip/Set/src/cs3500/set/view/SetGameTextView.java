package cs3500.set.view;

import cs3500.set.model.hw02.Cards;
import cs3500.set.model.hw02.SetGameModelState;

public class SetGameTextView implements SetGameView {

  private SetGameModelState model;

  public SetGameTextView(SetGameModelState model) throws IllegalArgumentException {
    if (model == null) {
      throw new IllegalArgumentException("Null model provided");
    }
    this.model = model;
  }


  public String toString(){

    int height = this.model.getHeight();
    int width = this.model.getWidth();
    String returning = "";

    for(int row = 0; row < height; row ++){
      for(int col = 0; col < width; col++){
        returning = returning + this.model.getCardAtCoord(row, col).toString();

        if(! (col == width - 1)){
          returning = returning + " ";
        }
      }
      if(! (row == height - 1)){
        returning = returning + "\n";
      }

    }
    return returning;
  }
}

// Testing
//assertEquals(view.toString(), "1ED 2FG\n3FG"
