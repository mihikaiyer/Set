package cs3500.set.model.hw02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Class representing the game.
 */

public class SetThreeGameModel implements SetGameModel<Cards> {
   private ArrayList<Cards> gameDeck;
   private ArrayList<Cards> copyDeck;
   private ArrayList<ArrayList<Cards>> board;
   private int height;
   private int width;
   private boolean gameStarted;
   private int score;
   private boolean gameEnded;

   /**
    * Constructor for SetThreeModel that initializes game with set values.
    */
   public SetThreeGameModel() {
      this.gameDeck = new ArrayList<Cards>();
      this.board = new ArrayList<ArrayList<Cards>>();
      this.copyDeck = new ArrayList<Cards>();
      this.height = 3;
      this.width = 3;
      this.gameStarted = false;
      this.score = 0;
      this.gameEnded = false;
   }

   @Override
   public int getWidth() throws IllegalStateException {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      return this.width;
   }

   @Override
   public int getHeight() throws IllegalStateException {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      return this.height;
   }

   @Override
   public int getScore() throws IllegalStateException {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      return this.score;
   }

   @Override
   public boolean isGameOver() {
      return (this.gameDeck.size() < 3 || !(this.anySetsPresent()));

   }

   @Override
   public Cards getCardAtCoord(int row, int col) {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      return this.board.get(row).get(col);
   }

   @Override
   public Cards getCardAtCoord(Coord coord) {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      return this.board.get(coord.row).get(coord.col);
   }

   @Override
   public boolean isValidSet(Coord coord1, Coord coord2, Coord coord3) throws IllegalArgumentException {

      if (this.gameStarted == false) {
         throw new IllegalStateException("Game has not started yet!");
      }

      int colHeight = this.height - 1;
      int rowWidth = this.width - 1;

      if (coord1.row < 0 || coord1.row > colHeight || coord1.col < 0 || coord1.col > rowWidth ||
          coord2.row < 0 || coord2.row > colHeight || coord2.col < 0 || coord2.col > rowWidth ||
          coord3.row < 0 || coord3.row > colHeight || coord3.col < 0 || coord3.col > rowWidth) {
         throw new IllegalArgumentException("Card not in Bounds");
      }

      if (coord1.equals(coord2) || coord1.equals(coord3) || coord2.equals(coord3)) {
         throw new IllegalArgumentException("Duplicate Coordinates");
      }

      Cards card1 = getCardAtCoord(coord1);
      Cards card2 = getCardAtCoord(coord2);
      Cards card3 = getCardAtCoord(coord3);

      int card1Num = card1.getNumber();
      Fill card1Fill = card1.getFill();
      Shape card1Shape = card1.getShape();

      int card2Num = card2.getNumber();
      Fill card2Fill = card2.getFill();
      Shape card2Shape = card2.getShape();

      int card3Num = card3.getNumber();
      Fill card3Fill = card3.getFill();
      Shape card3Shape = card3.getShape();

      boolean sameNums = card1Num == card2Num && card2Num == card3Num;
      boolean sameFills = card1Fill == card2Fill && card2Fill == card3Fill;
      boolean sameShapes = card1Shape == card2Shape && card2Shape == card3Shape;

      boolean diffNums = card1Num != card2Num && card2Num != card3Num
          && card1Num != card3Num;
      boolean diffFills = card1Fill != card2Fill && card2Fill != card3Fill
          && card1Fill != card3Fill;
      boolean diffShapes = card1Shape != card2Shape && card2Shape != card3Shape
          && card1Shape != card3Shape;

      return (sameNums && sameFills && diffShapes)
          || (sameFills && sameShapes && diffNums)
          || (sameShapes && sameNums && diffFills)
          || (sameNums && diffFills && diffShapes)
          || (sameFills && diffShapes && diffNums)
          || (sameShapes && diffNums && diffFills)
          || (diffNums && diffFills && diffShapes)
          || (sameNums && sameFills && sameShapes);

   }

   @Override
   public boolean anySetsPresent() {
      if (!this.gameStarted) {
         throw new IllegalStateException("Game has not started yet!");
      }
      //call isValidSet on every possible 3 coordinates,
      // (0,0) (0,1) (0,2)
      // (1,0) (1,1) (1,2)
      // (2,0) (2,1) (2,2)
      //if any of them are a valid set return true, otherwise return false

      for (int i = 0; i < this.board.size(); i++) {
         for (int j = 0; j < this.board.size(); j++) {
            Coord c1 = new Coord(i, j);
            for (int k = 0; k < this.board.size(); k++) {
               for (int l = 0; l < this.board.size(); l++) {
                  Coord c2 = new Coord(k, l);
                  for (int m = 0; m < this.board.size(); m++) {
                     for (int n = 0; n < this.board.size(); n++) {
                        Coord c3 = new Coord(m, n);
                        try {
                           if (isValidSet(c1, c2, c3)) {
                              return true;
                           }
                        } catch (IllegalArgumentException e) {
                        }
                     }
                  }
               }
            }
         }
      }
      return false;

   }

   @Override
   public List<Cards> getCompleteDeck() {
      List<Fill> fills = new ArrayList<>(Arrays.asList(Fill.FULL, Fill.EMPTY, Fill.STRIPED));
      List<Shape> shapes = new ArrayList<>(Arrays.asList(Shape.OVAL, Shape.SQUIGGLE, Shape.DIAMOND));
      List<Cards> result = new ArrayList<Cards>();

      for (int i = 0; i < 3; i++) {
         for (int j = 0; j < 3; j++) {
            for (int k = 1; k < 4; k++) {
               Cards card = new Cards(k, fills.get(i), shapes.get(j));
               result.add(card);
            }
         }
      }
      return result;
   }

   @Override
   public void claimSet(Coord coord1, Coord coord2, Coord coord3) {
      //throw an illegalStateException
      if (!this.gameStarted) {
         throw new IllegalStateException("Game is not currently running!");
      }

      if (!this.isValidSet(coord1, coord2, coord3)) {
         throw new IllegalArgumentException("Not a Valid Set!");
      } else {
         if (this.gameDeck.size() < 3) {
            this.gameEnded = true;
         }

         else {
            board.get(coord1.row).set(coord1.col, this.gameDeck.get(0));
            board.get(coord2.row).set(coord2.col, this.gameDeck.get(1));
            board.get(coord3.row).set(coord3.col, this.gameDeck.get(2));

            for (int i = 0; i < 3; i++) {
               this.gameDeck.remove(0);
            }
         }

         this.score += 1;
      }
   }

   @Override
   public void startGameWithDeck(List<Cards> deck, int height, int width) throws IllegalArgumentException {
      if ((!(height == 3 && width == 3)) || deck == null || (deck.size() < (height * width))) {
         throw new IllegalArgumentException("Empty Deck!");
      }

      //FOR LOOP TO COPY THEM
      for (int i = 0; i < deck.size(); i++) {
         this.gameDeck.add(deck.get(i));
         this.copyDeck.add(deck.get(i));
      }

      //CREATE YOUR BOARD
      for (int row = 0; row < this.width; row++) {
         ArrayList<Cards> column = new ArrayList<Cards>();

         for (int col = 0; col < this.height; col++) {
            column.add(deck.get((height * row) + col));
            this.gameDeck.remove(0);
         }

         this.board.add(column);
      }

      this.gameStarted = true;
   }

}
