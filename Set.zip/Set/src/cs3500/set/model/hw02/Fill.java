package cs3500.set.model.hw02;

import java.util.Objects;

public enum Fill {
    FULL, STRIPED, EMPTY


}
