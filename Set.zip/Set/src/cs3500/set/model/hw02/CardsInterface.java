package cs3500.set.model.hw02;

/**
 * Interface for the Cards in game of Set.
 */
public interface CardsInterface {

  /**
   * Observer method for number attribute.
   */
  int getNumber();

  /**
   * Observer method for fill attribute.
   */
  Fill getFill();

  /**
   * Observer method for shape attribute.
   */
  Shape getShape();

  /**
   * Converts provided Card's attributes into a string.
   */
  String toString();

}
