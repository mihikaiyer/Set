package cs3500.set.model.hw02;

import java.util.Objects;

/**
 * Class representing the cards for the game.
 */
public class Cards implements CardsInterface {

    //  a number of items (1, 2, 3)
    private int number;

    //  an enumeration Fill representing the fill of items (full, empty, striped)
    private Fill fill;

    //  an enumeration Shape representing the shape of items (diamond, squiggle, oval)
    private Shape shape;

    /**
     * Constructor for Cards that initializes game with set values.
     * @param number of objects on each card.
     * @param fill of objects on each card.
     * @param shape of objects on each card.
     * @throws IllegalArgumentException when the given values are invalid.
     */
    public Cards(int number, Fill fill, Shape shape) throws IllegalArgumentException {

        //throws exception if number of objects on card isn't between 1 and 3
        if (!(1 <= number && number <= 3)) {
            throw new IllegalArgumentException("Invalid number.");
        }

        //throws exception if fill is null
        if (fill == null) {
            throw new IllegalArgumentException("Fill is null");
        }

        //throws exception if shape is null
        if (shape == null) {
            throw new IllegalArgumentException("Shape is null");
        }

        //initializes values
        this.number = number;
        this.fill = fill;
        this.shape = shape;
    }

    /**
     * Observer method for number attribute.
     */
    public int getNumber() {
        return this.number;
    }

    /**
     * Observer method for fill attribute.
     */
    public Fill getFill() {
        return this.fill;
    }

    /**
     * Observer method for shape attribute.
     */
    public Shape getShape() {
        return this.shape;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Cards card = (Cards) o;
        return this.number == card.number && this.fill == card.fill && this.shape == card.shape;
    }

    @Override
    public int hashCode() {return Objects.hash(number, fill, shape);}

    /**
     * Converts provided Card's attributes into a string.
     */
    public String toString() {
        String returning = "";

        //NUMBER VALUE
        returning = returning + Integer.toString(this.number);

        //FILL VALUE
        if(this.fill == Fill.FULL){
            returning = returning + "F";
        }

        if(this.fill == Fill.EMPTY) {
            returning = returning + "E";
        }

        if(this.fill == Fill.STRIPED) {
            returning = returning + "S";
        }

        //SHAPE VALUE
        if(this.shape == Shape.OVAL){
            returning = returning + "O";
        }
        if(this.shape == Shape.DIAMOND) {
            returning = returning + "D";
        }
        if(this.shape == Shape.SQUIGGLE) {
            returning = returning + "Q";
        }

        return returning;
    }





}
