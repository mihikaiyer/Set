package cs3500.set.model.hw02;

public enum Shape {
    DIAMOND, SQUIGGLE, OVAL


}
